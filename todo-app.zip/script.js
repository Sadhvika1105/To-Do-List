// Select DOM Elements
const todoForm = document.getElementById('todo-form');
const taskInput = document.getElementById('task-input');
const taskList = document.getElementById('task-list');
const emptyState = document.getElementById('empty-state');

// Load tasks from LocalStorage on initial page load (or set to an empty array if none exist)
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

// Render tasks when the page loads
document.addEventListener('DOMContentLoaded', renderTasks);

// Handle form submit (adding a task)
todoForm.addEventListener('submit', function (event) {
  event.preventDefault(); // Prevent page refresh on submit

  const taskText = taskInput.value.trim(); // Trim whitespace

  // Input validation: Prevent adding empty tasks
  if (taskText === '') {
    alert('Please enter a task name.');
    return;
  }

  // Create a new task object
  const newTask = {
    id: Date.now(), // Unique ID based on timestamp
    text: taskText,
    completed: false
  };

  // Add the task to our array
  tasks.push(newTask);

  // Save updated tasks to LocalStorage
  saveTasksToLocalStorage();

  // Re-render the task list
  renderTasks();

  // Clear the input field
  taskInput.value = '';
});

// Save task array to LocalStorage
function saveTasksToLocalStorage() {
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Render task list in the HTML DOM
function renderTasks() {
  // Clear existing rendered list items
  taskList.innerHTML = '';

  // Show or hide the empty state message
  if (tasks.length === 0) {
    emptyState.classList.remove('hidden');
  } else {
    emptyState.classList.add('hidden');
  }

  // Iterate over each task in our list
  tasks.forEach((task) => {
    // Create list item element
    const li = document.createElement('li');
    li.className = `task-item ${task.completed ? 'completed' : ''}`;

    // Task content wrapper
    const taskContent = document.createElement('div');
    taskContent.className = 'task-content';

    // Checkbox to mark complete/incomplete
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = task.completed;
    checkbox.addEventListener('change', () => toggleTaskComplete(task.id));

    // Task text span
    const span = document.createElement('span');
    span.className = 'task-text';
    span.textContent = task.text;

    taskContent.appendChild(checkbox);
    taskContent.appendChild(span);

    // Action buttons container
    const taskActions = document.createElement('div');
    taskActions.className = 'task-actions';

    // Edit button
    const editBtn = document.createElement('button');
    editBtn.className = 'btn-edit';
    editBtn.textContent = 'Edit';
    editBtn.addEventListener('click', () => editTask(task.id));

    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn-delete';
    deleteBtn.textContent = 'Delete';
    deleteBtn.addEventListener('click', () => deleteTask(task.id));

    taskActions.appendChild(editBtn);
    taskActions.appendChild(deleteBtn);

    // Assemble the complete task item
    li.appendChild(taskContent);
    li.appendChild(taskActions);

    // Append task item to the list
    taskList.appendChild(li);
  });
}

// Toggle task completion status
function toggleTaskComplete(id) {
  tasks = tasks.map((task) => {
    if (task.id === id) {
      return { ...task, completed: !task.completed };
    }
    return task;
  });

  saveTasksToLocalStorage();
  renderTasks();
}

// Edit a task's text
function editTask(id) {
  const taskToEdit = tasks.find((task) => task.id === id);
  if (!taskToEdit) return;

  const newText = prompt('Edit your task:', taskToEdit.text);

  // Validate the edited text
  if (newText !== null) {
    const trimmedText = newText.trim();
    if (trimmedText === '') {
      alert('Task name cannot be empty.');
    } else {
      taskToEdit.text = trimmedText;
      saveTasksToLocalStorage();
      renderTasks();
    }
  }
}

// Delete a task by ID
function deleteTask(id) {
  tasks = tasks.filter((task) => task.id !== id);
  saveTasksToLocalStorage();
  renderTasks();
}